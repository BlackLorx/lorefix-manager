export default function Recepciones() {
  return (
    <div className="p-10">
      <h1 className="text-4xl font-bold">Recepciones</h1>

      <p className="text-gray-500 mt-2">
        Gestión de entradas de dispositivos.
      </p>
    </div>
  );
}